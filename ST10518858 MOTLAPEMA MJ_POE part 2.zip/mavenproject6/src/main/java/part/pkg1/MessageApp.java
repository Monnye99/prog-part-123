package part.pkg1;

import java.io.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class MessageApp {

    private static ArrayList<Message> sentMessages      = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages    = new ArrayList<>();
    private static ArrayList<String>  messageHashes     = new ArrayList<>();
    private static ArrayList<String>  messageIDs        = new ArrayList<>();

    private static final String JSON_FILE = "stored_messages.json";

    public static void main(String[] args) {
        loadStoredMessagesFromJSON(); // populate storedMessages array from file

        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Welcome to QuickChat.");

            boolean running = true;
            while (running) {
                System.out.println("\n--- Main Menu ---");
                System.out.println("1) Send Messages");
                System.out.println("2) Show Recently Sent Messages");
                System.out.println("3) Quit");
                System.out.println("4) Stored Messages");
                System.out.print("Choose option: ");

                String input = sc.nextLine().trim();
                if (!input.matches("[1-4]")) {
                    System.out.println("Invalid option. Please enter 1-4.");
                    continue;
                }

                switch (Integer.parseInt(input)) {
                    case 1 -> sendMessagesMenu(sc);
                    case 2 -> showSentMessages();
                    case 3 -> {
                        running = false;
                        System.out.println("Total messages sent: " + new Message().returnTotalMessages());
                    }
                    case 4 -> storedMessagesMenu(sc);
                }
            }
        }
    }

    //  SEND MESSAGES (existing logic, arrays added)
    
    private static void sendMessagesMenu(Scanner sc) {
        System.out.print("How many messages do you wish to enter? ");
        int maxMessages = Integer.parseInt(sc.nextLine());

        int messagesEntered = 0;
        while (messagesEntered < maxMessages) {
            Message msg = new Message();
            msg.setMessageNumber(messagesEntered + 1);
            msg.setMessageID();

            System.out.print("Enter recipient cell number (+27XXXXXXXXX): ");
            String recipient = sc.nextLine();
            msg.setRecipient(recipient);
            System.out.println(msg.checkRecipientCell());
            if (!recipient.matches("\\+27[0-9]{9}")) continue;

            System.out.print("Enter message (max 250 chars): ");
            String messageText = sc.nextLine();
            msg.setMessage(messageText);
            System.out.println(msg.validateMessageLength());
            if (messageText.length() > 250) continue;

            msg.createMessageHash();

            // Track hash and ID in arrays
            messageHashes.add(msg.getMessageHash());
            messageIDs.add(msg.getMessageID());

            System.out.println("\nChoose: 1) Send  2) Disregard  3) Store");
            int option = Integer.parseInt(sc.nextLine());
            System.out.println(msg.sentMessage(option));

            switch (option) {
                case 1 -> sentMessages.add(msg);
                case 2 -> disregardedMessages.add(msg);
                case 3 -> {
                    storedMessages.add(msg);
                    saveMessageToJSON(msg);
                }
                default -> {
                }
            }

            System.out.println("\n" + msg.printMessages());
            messagesEntered++;
        }
    }

    
    //  SHOW SENT MESSAGES
    private static void showSentMessages() {
        if (sentMessages.isEmpty()) {
            System.out.println("No messages sent yet.");
            return;
        }
        System.out.println("\n--- Sent Messages ---");
        for (Message m : sentMessages) {
            System.out.println(m.printMessages());
            System.out.println("---");
        }
    }

    
    //  STORED MESSAGES MENU (Part 3 requirement)
    
    private static void storedMessagesMenu(Scanner sc) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Stored Messages Menu ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search by Message ID");
            System.out.println("d) Search by recipient");
            System.out.println("e) Delete a message by hash");
            System.out.println("f) Display full report");
            System.out.println("0) Back to main menu");
            System.out.print("Choose option: ");

            String opt = sc.nextLine().trim().toLowerCase();
            switch (opt) {
                case "a" -> displaySendersAndRecipients();
                case "b" -> displayLongestMessage();
                case "c" -> searchByMessageID(sc);
                case "d" -> searchByRecipient(sc);
                case "e" -> deleteByHash(sc);
                case "f" -> displayFullReport();
                case "0" -> back = true;
                default  -> System.out.println("Invalid option.");
            }
        }
    }

    // a) Display sender and recipient of all stored messages
    private static void displaySendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
        System.out.println("\n--- Stored Messages: Sender & Recipient ---");
        for (Message m : storedMessages) {
            System.out.println("Message ID : " + m.getMessageID());
            System.out.println("Recipient  : " + m.getRecipient());
            System.out.println("---");
        }
    }

    // b) Display the longest stored message
    public static String getLongestMessage() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        Message longest = storedMessages.get(0);
        for (Message m : storedMessages) {
            if (m.getMessage().length() > longest.getMessage().length()) {
                longest = m;
            }
        }
        return longest.getMessage();
    }

    private static void displayLongestMessage() {
        System.out.println("Longest stored message: " + getLongestMessage());
    }

    // c) Search by message ID
    public static String searchByID(String id) {
        for (Message m : storedMessages) {
            if (m.getMessageID().equals(id)) {
                return "Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessage();
            }
        }
        // Also check sent messages
        for (Message m : sentMessages) {
            if (m.getMessageID().equals(id)) {
                return "Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessage();
            }
        }
        return "Message ID not found.";
    }

    private static void searchByMessageID(Scanner sc) {
        System.out.print("Enter Message ID to search: ");
        String id = sc.nextLine().trim();
        System.out.println(searchByID(id));
    }

    // d) Search all messages for a particular recipient
    public static ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(recipient)) results.add(m.getMessage());
        }
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(recipient)) results.add(m.getMessage());
        }
        return results;
    }

    private static void searchByRecipient(Scanner sc) {
        System.out.print("Enter recipient number to search: ");
        String rec = sc.nextLine().trim();
        ArrayList<String> results = searchByRecipient(rec);
        if (results.isEmpty()) {
            System.out.println("No messages found for " + rec);
        } else {
            System.out.println("Messages for " + rec + ":");
            results.forEach(System.out::println);
        }
    }

    // e) Delete a message using message hash
    public static String deleteByHash(String hash) {
        Iterator<Message> it = storedMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equals(hash)) {
                String text = m.getMessage();
                it.remove();
                messageHashes.remove(hash);
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "Hash not found.";
    }

    private static void deleteByHash(Scanner sc) {
        System.out.print("Enter message hash to delete: ");
        String hash = sc.nextLine().trim();
        System.out.println(deleteByHash(hash));
    }

    // f) Display full report
    public static String getFullReport() {
        if (storedMessages.isEmpty() && sentMessages.isEmpty()) return "No messages to report.";
        StringBuilder sb = new StringBuilder();
        sb.append("\n===== MESSAGE REPORT =====\n");
        for (Message m : sentMessages) {
            sb.append("Hash      : ").append(m.getMessageHash()).append("\n");
            sb.append("Recipient : ").append(m.getRecipient()).append("\n");
            sb.append("Message   : ").append(m.getMessage()).append("\n");
            sb.append("--------------------------\n");
        }
        for (Message m : storedMessages) {
            sb.append("Hash      : ").append(m.getMessageHash()).append("\n");
            sb.append("Recipient : ").append(m.getRecipient()).append("\n");
            sb.append("Message   : ").append(m.getMessage()).append("\n");
            sb.append("--------------------------\n");
        }
        return sb.toString(); 
    }

    private static void displayFullReport() {
        System.out.println(getFullReport());
    }

    
    //  JSON: Save and Load
    
    @SuppressWarnings("unchecked")
    private static void saveMessageToJSON(Message msg) {
        JSONArray array = readJSONFile();
        JSONObject obj = new JSONObject();
        obj.put("messageID",   msg.getMessageID());
        obj.put("recipient",   msg.getRecipient());
        obj.put("message",     msg.getMessage());
        obj.put("messageHash", msg.getMessageHash());
        array.add(obj);
        try (FileWriter fw = new FileWriter(JSON_FILE)) {
            fw.write(array.toJSONString());
        } catch (IOException e) {
            System.out.println("Error saving to JSON: " + e.getMessage());
        }
    }

    private static void loadStoredMessagesFromJSON() {
        JSONArray array = readJSONFile();
        for (Object o : array) {
            JSONObject obj = (JSONObject) o;
            Message msg = new Message();
            msg.setMessageID((String) obj.get("messageID"));
            msg.setRecipient((String) obj.get("recipient"));
            msg.setMessage((String) obj.get("message"));
            // hash is already stored — we re-create it so getter works
            msg.setMessageNumber(storedMessages.size() + 1);
            msg.createMessageHash();
            storedMessages.add(msg);
            messageHashes.add(msg.getMessageHash());
            messageIDs.add(msg.getMessageID());
        }
    }

    private static JSONArray readJSONFile() {
        File f = new File(JSON_FILE);
        if (!f.exists()) return new JSONArray();
        try (FileReader fr = new FileReader(f)) {
            return (JSONArray) new JSONParser().parse(fr);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    
    //  Helper: add test messages directly (for JUnit)
    
    public static void addToSent(Message m)     { sentMessages.add(m); }
    public static void addToStored(Message m)   { storedMessages.add(m); }
    public static void clearAll() {
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
    }
}
