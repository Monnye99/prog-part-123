package part.pkg1;

import java.util.Random;

public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private int messageNumber;
    private static int totalSent = 0;

    // Existing Part 1 & 2 methods 

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("\\+27[0-9]{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessageHash() {
        String idPart = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        messageHash = idPart + ":" + messageNumber + ":" + firstWord + lastWord;
        return messageHash;
    }

    public String sentMessage(int option) {
        switch (option) {
            case 1 -> { totalSent++; return "Message successfully sent."; }
            case 2 -> { return "Press 0 to delete the message."; }
            case 3 -> { return "Message successfully stored."; }
            default -> { return "Invalid option."; }
        }
    }

    public String printMessages() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }

    public int returnTotalMessages() {
        return totalSent;
    }

    public String validateMessageLength() {
        if (message.length() <= 250) return "Message ready to send.";
        int over = message.length() - 250;
        return "Message exceeds 250 characters by " + over + "; please reduce the size.";
    }

    //Getters (needed for Part 3)

    public String getMessageID()   { return messageID; }
    public String getRecipient()   { return recipient; }
    public String getMessage()     { return message; }
    public String getMessageHash() { return messageHash; }
    public int    getMessageNumber(){ return messageNumber; }

    //Setters

    public void setMessageID() {
        Random rand = new Random();
        this.messageID = String.format("%010d", rand.nextInt(1000000));
    }

    public void setMessageID(String id) {
        this.messageID = id;
    }

    public void setRecipient(String recipient)   { this.recipient = recipient; }
    public void setMessage(String message)       { this.message = message; }
    public void setMessageContent(String message){ this.message = message; }
    public void setMessageNumber(int num)        { this.messageNumber = num; }
}