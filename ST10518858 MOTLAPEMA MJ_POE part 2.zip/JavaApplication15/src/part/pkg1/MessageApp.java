package part.pkg1;

import java.util.ArrayList;
import java.util.Scanner;

public class MessageApp {
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();

    public static void main(String[] args) {
        // Part 2 assumes user is already logged in.
        try (Scanner sc = new Scanner(System.in)) {
            // Part 2 assumes user is already logged in. If not, call your Login code here.
            System.out.println("Welcome to QuickChat.");
            
            boolean running = true;
            while (running) {
                System.out.println("\n--- Menu ---");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages - Coming Soon");
                System.out.println("3) Quit");
                System.out.print("Choose option: ");
                
                int choice = Integer.parseInt(sc.nextLine());
                
                switch (choice) {
                    case 1 -> sendMessagesMenu(sc);
                    case 2 -> System.out.println("Coming Soon.");
                    case 3 -> {
                        running = false;
                        System.out.println("Total messages sent: " + new Message().returnTotalMessages());
                    }
                    default -> System.out.println("Invalid option.");
                }
            }
        }
    }

    private static void sendMessagesMenu(Scanner sc) {
        System.out.print("How many messages do you wish to enter? ");
        int maxMessages = Integer.parseInt(sc.nextLine());
        var messagesEntered = 0;

        while (messagesEntered < maxMessages) {
            Message msg = new Message();
            msg.setMessageNumber(messagesEntered + 1);
            msg.setMessageID();

            System.out.print("Enter recipient cell number (+27XXXXXXXXX): ");
            String recipient = sc.nextLine();
            msg.setRecipient(recipient);
            System.out.println(msg.checkRecipientCell());

            if (!recipient.matches("\\+27[0-9]{9}")) continue;

            System.out.print("Enter message (max 250 chars): ");
            String messageText = sc.nextLine();
            msg.setMessage(messageText);
            System.out.println(msg.validateMessageLength());

            if (messageText.length() > 250) continue;

            msg.createMessageHash();

            System.out.println("\nChoose: 1) Send 2) Disregard 3) Store to send later");
            int option = Integer.parseInt(sc.nextLine());
            System.out.println(msg.sentMessage(option));

            if (option == 1) {
                sentMessages.add(msg);
            } else if (option == 3) {
                storedMessages.add(msg);
            }

            System.out.println("\n" + msg.printMessages());
            messagesEntered++;
        }
    }
}