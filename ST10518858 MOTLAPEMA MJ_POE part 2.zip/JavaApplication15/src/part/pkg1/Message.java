package part.pkg1;

import java.util.Random;

public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private int messageNumber;
    private static int totalSent = 0;

    // Check Message ID is 10 characters maximum
    public boolean checkMessageID() {
        return messageID!= null && messageID.length() <= 10;
    }

    // Check recipient cell: must start with +27 and be 12 chars total
    public String checkRecipientCell() {
        if (recipient!= null && recipient.matches("\\+27[0-9]{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // Create Message Hash: first2ID:number:firstWordLASTWORD
    public String createMessageHash() {
        String idPart = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        messageHash = idPart + ":" + messageNumber + ":" + firstWord + lastWord;
        return messageHash;
    }

    // Send, Store, or Disregard message
    public String sentMessage(int option) {
        switch (option) {
            case 1 -> {
                totalSent++;
                return "Message successfully sent.";
            }
            case 2 -> {
                return "Press 0 to delete the message.";
            }
            case 3 -> {
                return "Message successfully stored.";
            }
            default -> {
                return "Invalid option.";
            }
        }
    }

    // Print all details in required order
    public String printMessages() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }

    public int returnTotalMessages() {
        return totalSent;
    }

    // Setters and generators
    public void setMessage(String message) {
        this.message = message;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setMessageID() {
        Random rand = new Random();
        this.messageID = String.format("%010d", rand.nextInt(1000000));
    }

    public void setMessageNumber(int num) {
        this.messageNumber = num;
    }

    // Check message length
    public String validateMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
    }

    void setMessageID(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setMessageContent(String hello) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getMessageHash() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}