package part.pkg1;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    
    @Test
    public void testCheckMessageID_Correct() {
        Message msg = new Message();
        msg.setMessageID("1234567890"); // 10 chars
        assertTrue(msg.checkMessageID());
    }
    
    @Test
    public void testCheckMessageID_WrongLength() {
        Message msg = new Message();
        msg.setMessageID("12345"); // 5 chars
        assertFalse(msg.checkMessageID());
    }
    
    @Test
    public void testCheckRecipientCell_Correct() {
        Message msg = new Message();
        msg.setRecipient("+27715237672"); //starts with + be 12 chars
        
    }
    
    @Test
    public void testCheckRecipientCell_WrongFormat() {
        Message msg = new Message();
        msg.setRecipient("0715237672"); // doesn't start with +
        
    }
    
    @Test
    public void testCreateMessageHash() {
        Message msg = new Message();
        msg.setMessageNumber(1);
        msg.setMessageContent("Hello");
        msg.createMessageHash();
         assertEquals("1:HE", msg.getMessageHash());
    }
    
    @Test
    public void testReturnTotalMessages() {
        Message msg = new Message();
        msg.setMessageNumber(5);
        assertEquals(5, msg.returnTotalMessages());
    }
}