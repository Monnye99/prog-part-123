package part.pkg1;

import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.*;

public class MessageTest {

    // ── helper: build a Message with all fields set ──
    private Message buildMessage(String id, String recipient,
                                  String text, int number) {
        Message m = new Message();
        m.setMessageID(id);
        m.setRecipient(recipient);
        m.setMessage(text);
        m.setMessageNumber(number);
        m.createMessageHash();
        return m;
    }

    @Before
    public void setUp() {
        MessageApp.clearAll();

        // Test Message 1 — Sent
        Message m1 = buildMessage("0000000001", "+27834557896",
                                   "Did you get the cake?", 1);
        MessageApp.addToSent(m1);

        // Test Message 2 — Stored
        Message m2 = buildMessage("0000000002", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", 2);
        MessageApp.addToStored(m2);

        // Test Message 3 — Stored
        Message m3 = buildMessage("0000000003", "+27834484567",
                                   "Yohoooo, I am at your gate.", 3);
        MessageApp.addToStored(m3);

        // Test Message 4 — Sent  (Developer field used as recipient)
        Message m4 = buildMessage("0838884567", "0838884567",
                                   "It is dinner time!", 4);
        MessageApp.addToSent(m4);

        // Test Message 5 — Stored
        Message m5 = buildMessage("0000000005", "+27838884567",
                                   "Ok, I am leaving without you.", 5);
        MessageApp.addToStored(m5);
    }

    // ── TEST 1: Sent Messages array correctly populated ──
    @Test
    public void testSentMessagesArrayPopulated() {
// Messages 1 and 4 are sent; check their text
                // We expose via searchByRecipient or full report;
        // easiest: call getFullReport and check it contains expected strings
        String report = MessageApp.getFullReport();
        assertTrue("Should contain cake message",
                report.contains("Did you get the cake?"));
        assertTrue("Should contain dinner message",
                report.contains("It is dinner time!"));
    }

    // ── TEST 2: Display the longest message ──
    @Test
    public void testLongestMessage() {
        String longest = MessageApp.getLongestMessage();
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
        );
    }

    // ── TEST 3: Search for message ID → returns correct message ──
    @Test
    public void testSearchByMessageID() {
        String result = MessageApp.searchByID("0838884567");
        assertTrue("Result should contain dinner message",
                result.contains("It is dinner time!"));
    }

    // ── TEST 4: Search by recipient → returns all their messages ──
    @Test
    public void testSearchByRecipient() {
        ArrayList<String> results =
                MessageApp.searchByRecipient("+27838884567");
        assertEquals("Should find 2 messages for this recipient", 2, results.size());
        assertTrue(results.contains(
                "Where are you? You are late! I have asked you to be on time."));
        assertTrue(results.contains("Ok, I am leaving without you."));
    }

    // ── TEST 5: Delete message by hash ──
    @Test
    public void testDeleteByHash() {
// Get the hash of message 2
                // Build it properly using the same logic
        Message m2 = buildMessage("0000000002", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", 2);
        String hash = m2.getMessageHash();

        // Add it fresh so we can delete it
        MessageApp.clearAll();
        MessageApp.addToStored(m2);

        String result = MessageApp.deleteByHash(hash);
        assertTrue("Should confirm deletion",
                result.contains("successfully deleted"));
        assertTrue("Should name the message",
                result.contains("Where are you?"));
    }

    // ── Existing Part 1 & 2 tests kept ──
    @Test
    public void testCheckMessageID_Valid() {
        Message msg = new Message();
        msg.setMessageID("1234567890");
        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testCheckRecipientCell_Valid() {
        Message msg = new Message();
        msg.setRecipient("+27715237672");
        assertEquals("Cell phone number successfully captured.",
                msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_Invalid() {
        Message msg = new Message();
        msg.setRecipient("0715237672");
        assertFalse(msg.checkRecipientCell().contains("successfully"));
    }

    @Test
    public void testValidateMessageLength_OK() {
        Message msg = new Message();
        msg.setMessage("Hello");
        assertEquals("Message ready to send.", msg.validateMessageLength());
    }
}
